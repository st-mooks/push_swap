/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   test_3way.h                                       :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: kalnajja <kalnajja@student.42amman.com>   #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/11/18 23:54:06 by kalnajja         #+#    #+#              */
/*   Updated: 2026/11/18 23:54:06 by kalnajja        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#ifndef TEST_3WAY_H
# define TEST_3WAY_H

# include "../../push_swap.h"
# include "../../algorithm/complex_3way/complex_3way.h"
# include <stdio.h>
# include <stdlib.h>

void	test_push(t_stack **stack, int value);
void	test_print_stack(t_stack *stack);
int		test_is_sorted(t_stack *stack);
void	test_free_stack(t_stack *stack);

#endif
