/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   complex_3way.h                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kalnajja <kalnajja@student.42amman.com>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/18 16:15:11 by kalnajja          #+#    #+#             */
/*   Updated: 2026/11/18 23:50:36 by kalnajja         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef COMPLEX_3WAY_H
# define COMPLEX_3WAY_H

# define STACK_A_TOP 0
# define STACK_A_BOTTOM 1
# define STACK_B_TOP 2
# define STACK_B_BOTTOM 3

# define GROUP_MAX 0
# define GROUP_MIDDLE 1
# define GROUP_MIN 2

# include "../../push_swap.h"

typedef struct s_segment
{
	int	location;
	int	lowest_index;
	int	element_count;
	int	min_boundary;
	int	max_boundary;
}	t_segment;

int		destination_of(int location, int group);
int		get_group(int index, t_segment *segment);
void	fetch_segment(t_stack **a, t_stack **b, t_ops **ops, int location);
void	move_from_a(t_stack **a, t_stack **b, t_ops **ops, int destination);
void	move_from_b(t_stack **a, t_stack **b, t_ops **ops, int destination);
void	sort_three_a(t_stack **a, t_ops **ops);
void	sort_three_b(t_stack **b, t_ops **ops);
void	base_sort(t_stack **a, t_stack **b, t_ops **ops, t_segment *segment);
void	process_element(t_stack **a, t_stack **b,
			t_ops	**ops, t_segment *segment);
void	set_boundaries(t_segment *segment);
void	solve_segments(t_stack **a, t_stack **b,
			t_ops **ops, t_segment *segment);
void	set_segment(t_segment *segment, int location,
			int lowest_index, int element_count);
t_ops	*three_way_sort(t_stack **a);
#endif
