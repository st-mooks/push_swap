/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   medium_push.c                                     :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: kalnajja <kalnajja@student.42amman.com>   #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/11/13 18:54:25 by kalnajja         #+#    #+#              */
/*   Updated: 2026/11/14 16:33:48 by kalnajja        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "medium.h"

void	chunk_push_to_b(t_stack **a, t_stack **b, t_chunk chunk, t_ops **ops)
{
	int	i;
	int	size;

	size = stack_size(*a);
	i = 0;
	while (i < size && *a)
	{
		if ((*a)->index >= chunk.start && (*a)->index < chunk.end)
			pb(a, b, ops);
		else
			ra(a, ops);
		i++;
	}
}

void	push_back_to_a(t_stack **a, t_stack **b, t_ops **ops)
{
	int	max;

	while (*b)
	{
		max = get_max_index(*b);
		bring_to_top_b(b, max, ops);
		pa(a, b, ops);
	}
}
