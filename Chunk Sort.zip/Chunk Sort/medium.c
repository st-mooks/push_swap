/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   medium.c                                          :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: kalnajja <kalnajja@student.42amman.com>   #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/11/13 18:54:20 by kalnajja         #+#    #+#              */
/*   Updated: 2026/11/14 16:36:45 by kalnajja        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "medium.h"

void	chunk_sort(t_stack **a, t_stack **b, t_ops **ops)
{
	int		size;
	int		chunk_count;
	int		chunk_size;
	t_chunk	chunk;
	int		i;

	size = stack_size(*a);
	if (size == 0)
		return ;
	chunk_count = get_chunk_count(size);
	chunk_size = (size + chunk_count - 1) / chunk_count;
	i = 0;
	while (i < chunk_count)
	{
		chunk.start = i * chunk_size;
		chunk.end = chunk.start + chunk_size;
		if (chunk.end > size)
			chunk.end = size;
		chunk_push_to_b(a, b, chunk, ops);
		i++;
	}
	push_back_to_a(a, b, ops);
}
