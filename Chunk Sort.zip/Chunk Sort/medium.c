/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   medium.c                                          :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: kalnajja <kalnajja@student.42amman.com>   #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/11/13 18:54:20 by kalnajja         #+#    #+#              */
/*   Updated: 2026/11/16 10:30:38 by kalnajja        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "medium.h"

int	get_chunk_size(int size)
{
	if (size <= 100)
		return (15);
	return (30);
}

void	chunk_sort(t_stack **a, t_stack **b, t_ops **ops)
{
	int	size;

	size = stack_size(*a);
	if (size == 0)
		return ;
	chunk_push_to_b(a, b, get_chunk_size(size), ops);
	push_back_to_a(a, b, ops);
}
