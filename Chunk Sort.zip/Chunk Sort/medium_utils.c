/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   medium_utils.c                                    :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: kalnajja <kalnajja@student.42amman.com>   #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/11/13 18:54:24 by kalnajja         #+#    #+#              */
/*   Updated: 2026/11/16 10:15:44 by kalnajja        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "medium.h"

int	stack_size(t_stack *stack)
{
	int	counter;

	counter = 0;
	while (stack)
	{
		counter++;
		stack = stack->next;
	}
	return (counter);
}

int	get_pos(t_stack *stack, int idx)
{
	t_stack	*cur;
	int		pos;

	cur = stack;
	pos = 0;
	while (cur)
	{
		if (cur->index == idx)
			return (pos);
		cur = cur->next;
		pos++;
	}
	return (-1);
}

void	bring_to_top_b(t_stack **b, int idx, t_ops **ops)
{
	int	pos;
	int	size;

	pos = get_pos(*b, idx);
	size = stack_size(*b);
	if (pos == -1)
		return ;
	if (pos <= size / 2)
	{
		while (pos > 0)
		{
			rb(b, ops);
			pos--;
		}
	}
	else
	{
		pos = size - pos;
		while (pos > 0)
		{
			rrb(b, ops);
			pos--;
		}
	}
}

int	get_max_index(t_stack *stack)
{
	int	max;

	max = stack->index;
	while (stack)
	{
		if (stack->index > max)
			max = stack->index;
		stack = stack->next;
	}
	return (max);
}

void	assign_index(t_stack *stack)
{
	t_stack	*current;
	t_stack	*runner;
	int		index;

	index = 0;
	current = stack;
	while (current)
	{
		runner = stack;
		while (runner)
		{
			if (runner->value < current->value)
				index++;
			runner = runner->next;
		}
		current->index = index;
		index = 0;
		current = current->next;
	}
}
