/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   medium.h                                          :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: kalnajja <kalnajja@student.42amman.com>   #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/11/13 18:45:37 by kalnajja         #+#    #+#              */
/*   Updated: 2026/11/14 16:51:33 by kalnajja        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#ifndef MEDIUM_H
# define MEDIUM_H

# include "../push_swap.h"

typedef struct s_chunk
{
	int	start;
	int	end;
}	t_chunk;

int		stack_size(t_stack *stack);
int		get_pos(t_stack *s, int idx);
void	bring_to_top_b(t_stack **b, int idx, t_ops **ops);
int		get_chunk_count(int size);
void	chunk_push_to_b(t_stack **a, t_stack **b, t_chunk chunk, t_ops **ops);
void	push_back_to_a(t_stack **a, t_stack **b, t_ops **ops);
void	chunk_sort(t_stack **a, t_stack **b, t_ops **ops);
int		get_max_index(t_stack *stack);
void	assign_index(t_stack *stack);
#endif
